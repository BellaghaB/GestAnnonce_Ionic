import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-type-annonce',
  templateUrl: './type-annonce.page.html',
  styleUrls: ['./type-annonce.page.scss'],
})
export class TypeAnnoncePage implements OnInit {
selectedOption;
  constructor() { }

  ngOnInit() {
  }

}
